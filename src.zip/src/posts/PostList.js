import React, { Component } from 'react'
//import PostData from "../data/posts.json";
//import PostData from "../data/data.json";
class PostList extends Component {
  state = {
    todos: []
  }
  componentDidMount() {
    fetch('https://test.ausvdc02.pcf.dell.com/server')
    .then(res => res.json())
    .then((PostData) => {
      this.setState({ todos: PostData })
      console.log(this.state.todos)
    })
    .catch(console.log)
  }

  render() {

    return (
      <div >
        <h1>Hello There</h1>
        {this.state.todos.body.map((postDetail, index)=>{
          return <h1>{postDetail.name}</h1>


        })}
      </div>
    )
  }
}

 /* render () {
    return (
      <div >
        <h1>Hello There</h1>
        {PostData.body.items.map((postDetail, index)=>{
          return <h1>{postDetail.name}</h1>


        })}
      </div>
    )
  }
}*/

export default PostList
